# Changelog

All notable changes to this project will be documented in the [releases](https://github.com/facebook/metro/releases) section.
