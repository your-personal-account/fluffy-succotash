# metro-resolver

🚇 [Metro](https://facebook.github.io/metro/) resolution logic
