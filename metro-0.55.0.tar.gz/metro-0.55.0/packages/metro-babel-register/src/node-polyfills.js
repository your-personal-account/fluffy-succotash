/**
 * Copyright (c) Facebook, Inc. and its affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 *
 * @format
 */

'use strict';

Array.prototype.values || require('core-js/fn/array/values');
Object.entries || require('core-js/fn/object/entries');
Object.values || require('core-js/fn/object/values');
