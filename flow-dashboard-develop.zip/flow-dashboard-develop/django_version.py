import os
os.environ["DJANGO_SETTINGS_MODULE"] = "settings"

