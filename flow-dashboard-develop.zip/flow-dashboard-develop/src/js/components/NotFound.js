var React = require('react');

export default class NotFound extends React.Component{
  render() {
    return (
      <div>
      <h1>Not Found</h1>
      </div>
    );
  }
};
