var Styles = {
    // Unused currently
    Dialog: {
        contentStyle: {
            width: '100%',
            maxWidth: '550px',
            maxHeight: '100% !important'
        },
        bodyStyle: {
            maxHeight: '100% !important'
        },
        style: {
            paddingTop: '0 !important',
            marginTop: '-65px !important',
            bottom: '0 !important',
            overflow: 'scroll !important',
            height: 'auto !important'
        }
    }
}

module.exports = Styles;