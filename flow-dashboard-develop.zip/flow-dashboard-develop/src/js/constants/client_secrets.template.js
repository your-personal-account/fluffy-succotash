var client_secrets = {

	// Match with settings/secrets.py and GCP console
	G_OAUTH_CLIENT_ID: "######.XXXXXXXXXXXX.apps.googleusercontent.com",
	DEV_G_OAUTH_CLIENT_ID: "######.XXXXXXXXXXXX.apps.googleusercontent.com",
	GOOGLE_API_KEY: "XXXXXXXXXXXX",

	// Goodreads
	GR_API_KEY: ""
};

module.exports = client_secrets;