
Execute ./run_tests.sh to run all tests in this folder